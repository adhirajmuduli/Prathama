# Trendsmapp export bundle

Run: `run_67fd14c902cf4d2682edc68e5f769d44`
Recipe SHA-256: `553a6fe251eb0dace006ca05b2eea88fa9de4633ceaca82c439fc5c54d96a4e9`

Contents: `manifest.json` (full reproducibility record), `checksums.sha256` (SHA-256 of every member), `methods.json`, `data-dictionary.json`, `tables/` (CSV result tables), `artifacts/` (run outputs), `dataset/` (dataset version reports).

Verify: `trendsmapp reproduce <this-file.zip>`
