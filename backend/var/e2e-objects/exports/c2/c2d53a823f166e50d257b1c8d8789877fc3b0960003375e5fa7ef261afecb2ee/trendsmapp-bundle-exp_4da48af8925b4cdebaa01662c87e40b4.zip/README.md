# Trendsmapp export bundle

Run: `run_ead4e58cee9941b6b5c3b6aaddfc7fa7`
Recipe SHA-256: `480487b73fb774c34e94e349ab6ef476ea66ef537301278679b9510f07799af7`

Contents: `manifest.json` (full reproducibility record), `checksums.sha256` (SHA-256 of every member), `methods.json`, `data-dictionary.json`, `tables/` (CSV result tables), `artifacts/` (run outputs), `dataset/` (dataset version reports).

Verify: `trendsmapp reproduce <this-file.zip>`
