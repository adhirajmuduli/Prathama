# Trendsmapp export bundle

Run: `run_ffa7d41818bb41c6a083d85c434573a6`
Recipe SHA-256: `e001e600e37b663fa615a738af198b75368c31c1fc7834246543bfef9f2adaa8`

Contents: `manifest.json` (full reproducibility record), `checksums.sha256` (SHA-256 of every member), `methods.json`, `data-dictionary.json`, `tables/` (CSV result tables), `artifacts/` (run outputs), `dataset/` (dataset version reports).

Verify: `trendsmapp reproduce <this-file.zip>`
